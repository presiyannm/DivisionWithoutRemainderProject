using NUnit.Framework;
using DivisionWithoutRemainderConsoleMVC.Models;
using System.Collections.Generic;

namespace DivisionWithoutRemainderConsoleMVCTests
{
    /// <summary>
    /// Contains tests for the DivisonModel class.
    /// </summary>
    [TestFixture]
    public class DivisonModelTests
    {
        /// <summary>
        /// Tests the GetNumbersDividedWithoutRemainderPercentageEntries method to ensure correct percentages are returned.
        /// </summary>
        [Test]
        public void GetNumbersDividedWithoutRemainderPercentageEntries_ReturnsCorrectPercentages()
        {
            // Arrange
            List<int> numberEntries = new List<int> { 2, 3, 4, 6, 8, 9, 12, 15, 16 };
            DivisonModel divisionModel = new DivisonModel(numberEntries);

            // Act
            List<double> result = divisionModel.GetNumbersDividedWithoutRemainderPercentageEntries();

            // Assert
            Assert.AreEqual(66.67, Math.Round(result[0], 2));
            Assert.AreEqual(55.56, Math.Round(result[1], 2));
            Assert.AreEqual(44.44, Math.Round(result[2], 2));
        }

        /// <summary>
        /// Tests the CalculatePercentageForPartition method to ensure correct percentage is calculated.
        /// </summary>
        [Test]
        public void CalculatePercentageForPartition_ReturnsCorrectPercentage()
        {
            // Arrange
            DivisonModel divisionModel = new DivisonModel(new List<int>());

            // Act
            double result = divisionModel.CalculatePercentageForPartition(3, 10);

            // Assert
            Assert.AreEqual(30, result);
        }

        /// <summary>
        /// Tests the constructor of DivisonModel to ensure correct initialization of NumberEntries.
        /// </summary>
        [Test]
        public void Constructor_SavesValuesCorrectly()
        {
            // Arrange
            List<int> numberEntries = new List<int> { 2, 3, 4, 6, 8, 9, 12, 15, 16 };

            // Act
            DivisonModel divisonModel = new DivisonModel(numberEntries);

            // Assert
            Assert.AreEqual(divisonModel.NumberEntries.Count, numberEntries.Count);
            Assert.AreEqual(divisonModel.NumberEntries, new List<int> { 2, 3, 4, 6, 8, 9, 12, 15, 16 });
        }
    }
}
