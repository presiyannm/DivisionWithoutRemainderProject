﻿using DivisionWithoutRemainderConsoleMVC.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisionWithoutRemainderConsoleMVCTests
{
    [TestFixture]
    public class DivisionDisplayTests
    {
        [Test]
        public void ShowNumbersDividedWithoutRemainderPartitionPercentages_WritesToConsole()
        {
            //Arrange
            List<double> percentages = new List<double> { 50.0, 33.33, 25.0 }; 
            DivisonDisplay divisionDisplay = new DivisonDisplay { NumberDividedWithoutRamainderPartitionPercentages = percentages };
            StringBuilder expectedOutput = new();
            percentages.ForEach((percentage) => expectedOutput.AppendLine($"{percentage:f2}%"));
            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act
            divisionDisplay.ShowNumbersDividedWithoutRemainderPartitionPercentages();
            var consoleOutput = stringWriter.ToString();

            //Assert
            Assert.AreEqual(expectedOutput.ToString(), consoleOutput);
        }
    }
}
