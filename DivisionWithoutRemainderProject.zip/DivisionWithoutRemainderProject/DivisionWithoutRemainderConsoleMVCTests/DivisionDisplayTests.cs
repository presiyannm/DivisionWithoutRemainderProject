﻿using DivisionWithoutRemainderConsoleMVC.Views;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DivisionWithoutRemainderConsoleMVCTests
{
    /// <summary>
    /// Contains tests for the DivisionDisplay class.
    /// </summary>
    [TestFixture]
    public class DivisionDisplayTests
    {
        /// <summary>
        /// Tests the ShowNumbersDividedWithoutRemainderPartitionPercentages method to ensure correct output to the console.
        /// </summary>
        [Test]
        public void ShowNumbersDividedWithoutRemainderPartitionPercentages_WritesToConsole()
        {
            // Arrange
            List<double> percentages = new List<double> { 50.0, 33.33, 25.0 };
            DivisonDisplay divisionDisplay = new DivisonDisplay { NumberDividedWithoutRamainderPartitionPercentages = percentages };
            StringBuilder expectedOutput = new();
            percentages.ForEach((percentage) => expectedOutput.AppendLine($"{percentage:f2}%"));
            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            // Act
            divisionDisplay.ShowNumbersDividedWithoutRemainderPartitionPercentages();
            var consoleOutput = stringWriter.ToString();

            // Assert
            Assert.AreEqual(expectedOutput.ToString(), consoleOutput);
        }
    }
}
