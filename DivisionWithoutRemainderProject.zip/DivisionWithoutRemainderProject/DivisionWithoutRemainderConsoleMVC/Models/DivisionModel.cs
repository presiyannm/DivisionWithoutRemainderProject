﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisionWithoutRemainderConsoleMVC.Models
{
    public class DivisonModel
    {
        private List<int> numberEntries;

        public DivisonModel(List<int> numberEntries)
        {
            NumberEntries = numberEntries;
        }

        public List<int> NumberEntries
        {
            get
            {
                return numberEntries;
            }

            set
            {
                numberEntries = value;
            }
        }

        public List<double> GetNumbersDividedWithoutRemainderPercentageEntries()
        {
            int allHistogramEntriesCount = NumberEntries.Count;

            List<int> firstRangeNumbers = NumberEntries.Where(n => n % 2 == 0).ToList();
            double firstRangeNumbersPercentage = CalculatePercentageForPartition(firstRangeNumbers.Count, allHistogramEntriesCount);

            List<int> secondRangeNumbers = NumberEntries.Where(n => n % 3 == 0).ToList();
            double secondRangeNumbersPercentage = CalculatePercentageForPartition(secondRangeNumbers.Count, allHistogramEntriesCount);

            List<int> thirdRangeNumbers = NumberEntries.Where(n => n % 4 == 0).ToList();
            double thirdRangeNumbersPercentage = CalculatePercentageForPartition(thirdRangeNumbers.Count, allHistogramEntriesCount);

            List<double> numbersDividedWithoutRemainderPercentageEntries = new List<double>
            {
                firstRangeNumbersPercentage,
                secondRangeNumbersPercentage,
                thirdRangeNumbersPercentage
            };

            return numbersDividedWithoutRemainderPercentageEntries;
        }

        public double CalculatePercentageForPartition(int partitionEntriesCount, int totalEntriesCount)
        {
            return (double)partitionEntriesCount / totalEntriesCount * 100;
        }
    }
}
