﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisionWithoutRemainderConsoleMVC.Models
{
    /// <summary>
    /// Represents a model for performing division-related calculations.
    /// </summary>
    public class DivisonModel
    {
        private List<int> numberEntries;
        /// <summary>
        /// Initializes a new instance of the <see cref="DivisonModel"/> class.
        /// </summary>
        /// <param name="numberEntries">The list of numbers for calculations.</param>
        public DivisonModel(List<int> numberEntries)
        {
            NumberEntries = numberEntries;
        }
        /// <summary>
        /// Gets or sets the list of numbers for calculations.
        /// </summary>
        public List<int> NumberEntries
        {
            get
            {
                return numberEntries;
            }

            set
            {
                numberEntries = value;
            }
        }
        /// <summary>
        /// Retrieves percentages of numbers divided without remainder in specific ranges.
        /// </summary>
        /// <returns>A list of percentages for numbers divided without remainder in different ranges.</returns>
        public List<double> GetNumbersDividedWithoutRemainderPercentageEntries()
        {
            int allHistogramEntriesCount = NumberEntries.Count;

            List<int> firstRangeNumbers = NumberEntries.Where(n => n % 2 == 0).ToList();
            double firstRangeNumbersPercentage = CalculatePercentageForPartition(firstRangeNumbers.Count, allHistogramEntriesCount);

            List<int> secondRangeNumbers = NumberEntries.Where(n => n % 3 == 0).ToList();
            double secondRangeNumbersPercentage = CalculatePercentageForPartition(secondRangeNumbers.Count, allHistogramEntriesCount);

            List<int> thirdRangeNumbers = NumberEntries.Where(n => n % 4 == 0).ToList();
            double thirdRangeNumbersPercentage = CalculatePercentageForPartition(thirdRangeNumbers.Count, allHistogramEntriesCount);

            List<double> numbersDividedWithoutRemainderPercentageEntries = new List<double>
            {
                firstRangeNumbersPercentage,
                secondRangeNumbersPercentage,
                thirdRangeNumbersPercentage
            };

            return numbersDividedWithoutRemainderPercentageEntries;
        }
        /// <summary>
        /// Calculates the percentage for a partition based on the number of entries in the partition and the total entries count.
        /// </summary>
        /// <param name="partitionEntriesCount">The count of entries in the partition.</param>
        /// <param name="totalEntriesCount">The total count of entries.</param>
        /// <returns>The calculated percentage for the partition.</returns>
        public double CalculatePercentageForPartition(int partitionEntriesCount, int totalEntriesCount)
        {
            return (double)partitionEntriesCount / totalEntriesCount * 100;
        }
    }
}
