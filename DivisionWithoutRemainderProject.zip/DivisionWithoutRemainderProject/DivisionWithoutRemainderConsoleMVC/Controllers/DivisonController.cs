﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DivisionWithoutRemainderConsoleMVC.Models;
using DivisionWithoutRemainderConsoleMVC.Views;

namespace DivisionWithoutRemainderConsoleMVC.Controllers
{
    /// <summary>
    /// Represents a controller responsible for coordinating division-related functionalities.
    /// </summary>
    public class DivisionController
    {
        private DivisonModel model;
        private DivisonDisplay display;

        /// <summary>
        /// Initializes a new instance of the <see cref="DivisionController"/> class.
        /// Sets up the model, display, and shows calculated percentages.
        /// </summary>
        public DivisionController()
        {
            display = new DivisonDisplay();
            model = new DivisonModel(display.NumberEntries);
            display.NumberDividedWithoutRamainderPartitionPercentages = model.GetNumbersDividedWithoutRemainderPercentageEntries();
            display.ShowNumbersDividedWithoutRemainderPartitionPercentages();
        }
    }
}
