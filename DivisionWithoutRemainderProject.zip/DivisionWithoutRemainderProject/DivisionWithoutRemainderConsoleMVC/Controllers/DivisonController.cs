﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DivisionWithoutRemainderConsoleMVC.Models;
using DivisionWithoutRemainderConsoleMVC.Views;

namespace DivisionWithoutRemainderConsoleMVC.Controllers
{
    public class DivisionController
    {
        private DivisonModel model;

        private DivisonDisplay display;

        public DivisionController()
        {
            display = new DivisonDisplay();
            model = new DivisonModel(display.NumberEntries);
            display.NumberDividedWithoutRamainderPartitionPercentages = model.GetNumbersDividedWithoutRemainderPercentageEntries();
            display.ShowNumbersDividedWithoutRemainderPartitionPercentages();
        }
    }
}
