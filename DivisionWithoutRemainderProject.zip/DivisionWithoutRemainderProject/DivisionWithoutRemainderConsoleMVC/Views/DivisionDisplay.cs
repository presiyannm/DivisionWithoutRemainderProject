﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisionWithoutRemainderConsoleMVC.Views
{
    /// <summary>
    /// Represents a display view for presenting division-related data.
    /// </summary>
    public class DivisonDisplay
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DivisonDisplay"/> class and collects input values.
        /// </summary>
        public DivisonDisplay()
        {
            GetValues();
        }
        /// <summary>
        /// Gets or sets the list of numbers entered by the user.
        /// </summary>
        public List<int> NumberEntries { get; set; }
        /// <summary>
        /// Gets or sets the percentages of numbers divided without remainder in specific partitions.
        /// </summary>
        public List<double> NumberDividedWithoutRamainderPartitionPercentages { get; set; }
        /// <summary>
        /// Displays the percentages of numbers divided without remainder in specific partitions.
        /// </summary>
        public void ShowNumbersDividedWithoutRemainderPartitionPercentages()
        {
            NumberDividedWithoutRamainderPartitionPercentages.ForEach((percentageEntry) =>
            {
                Console.WriteLine("{0:F2}%", percentageEntry);
            });
        }
        /// <summary>
        /// Retrieves user input values and populates the NumberEntries list.
        /// </summary>
        private void GetValues()
        {
            int numbersCount = int.Parse(Console.ReadLine());
            NumberEntries = new List<int>(numbersCount);

            for (int i = 0; i < numbersCount; i++)
            {
                NumberEntries.Add(int.Parse(Console.ReadLine()));
            }
        }
    }
}
