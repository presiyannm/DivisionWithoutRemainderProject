﻿using DivisionWithoutRemainderConsoleMVC;
using DivisionWithoutRemainderConsoleMVC.Controllers;

DivisionController divisionWithoutRemainderController = new DivisionController();
